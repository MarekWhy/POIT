import serial
import time
from threading import Lock
from flask import Flask, render_template, session, request, jsonify, url_for
from flask_socketio import SocketIO, emit, disconnect
import random
import math

# Inicializácia sériového pripojenia
ser = serial.Serial("/dev/ttyACM0", 9600, timeout=1000)
ser.baudrate = 9600

# Skontrolovanie, či sériový port je otvorený
if not ser.is_open:
    ser.open()

# Nastavenie Flask aplikácie
async_mode = None
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, async_mode=async_mode)
thread = None
thread_lock = Lock()

# Príznak pre generovanie dát
generate = True

# Funkcia pre čítanie dát zo sériového portu
def Serial():
    Number = 0  # Predvolená hodnota, ak nie sú prijaté žiadne dáta
    try:
        # Čítanie správy zo sériového portu
        IncomeMessage = ser.readline().decode("latin1").strip()
        if IncomeMessage:
            print(f"Prijatá surová správa: {IncomeMessage}")  # Výstup pre ladenie
            if IncomeMessage.isdigit():  # Kontrola, či je správa platné celé číslo
                Number = int(IncomeMessage)
                print(f"Prevedené na číslo: {Number}")  # Výstup pre ladenie
            else:
                print("Prijatá správa nie je číslo")  # Výstup pre ladenie
        else:
            print("Žiadne dáta v sériovom bufferi")  # Výstup pre ladenie
    except serial.SerialException as e:
        print(f"Vyskytla sa sér. výnimka: {e}")
    return Number

# Funkcia pre bežiaci pozadí vlákno
def background_thread(args):
    count = 0
    global generate
    while True:
        if generate:
            time.sleep(1)
            count = Serial()
            # Odošle dáta klientom pomocou Socket.IO
            socketio.emit('my_response', {'data': count}, namespace='/test')

# Hlavná stránka aplikácie
@app.route('/')
def index():
    return render_template('tabs.html', async_mode=socketio.async_mode)

# Riešenie žiadosti o odpojenie
@socketio.on('disconnect_request', namespace='/test')
def disconnect_request():
    emit('my_response', {'data': 'Odpojené!'})
    disconnect()

# Riešenie žiadosti o generovanie dát
@socketio.on('generate_request', namespace='/test')
def generate_request():
    global generate
    generate = not generate
    message = "F" if generate else "N"
    byte_message = message.encode("latin1")
    ser.write(byte_message)

# Riešenie pripojenia klienta
@socketio.on('connect', namespace='/test')
def test_connect():
    global thread
    with thread_lock:
        if thread is None:
            thread = socketio.start_background_task(target=background_thread, args=session._get_current_object())
    emit('my_response', {'data': 'Pripojené'})
    message = "F"
    byte_message = message.encode("latin1")
    ser.write(byte_message)

# Riešenie odpojenia klienta
@socketio.on('disconnect', namespace='/test')
def test_disconnect():
    print('Klient odpojený', request.sid)
    message = "N"
    byte_message = message.encode("latin1")
    ser.write(byte_message)

# Hlavný vstup aplikácie
if __name__ == '__main__':
    socketio.run(app, host="0.0.0.0", port=80, debug=True)
